import history from "browserHistory";

const Logo = ({ className = "" }) => {
  return (
    <div
      className={"font-weight-bold text-white " + className}
      style={{ fontSize: 20 }}
      onClick={() => history.push("/")}
    >
      Anomaly detector
    </div>
  );
};

export default Logo;
